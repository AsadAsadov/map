const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs/promises');
const dns = require('dns').promises;
const net = require('net');
const ExcelJS = require('exceljs');

const USER_AGENT = 'MapLeadsDesktop/1.0 (business-data-research; contact: local-desktop-app)';
const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search';
const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter'
];

const CATEGORY_FILTERS = {
  restaurant: ['["amenity"="restaurant"]', '["amenity"="fast_food"]', '["amenity"="cafe"]'],
  hotel: ['["tourism"="hotel"]', '["tourism"="guest_house"]', '["tourism"="hostel"]'],
  pharmacy: ['["amenity"="pharmacy"]'],
  clinic: ['["amenity"="clinic"]', '["amenity"="hospital"]', '["healthcare"]'],
  market: ['["shop"="supermarket"]', '["shop"="convenience"]', '["shop"="mall"]'],
  beauty: ['["shop"="beauty"]', '["shop"="hairdresser"]'],
  education: ['["amenity"="school"]', '["amenity"="college"]', '["amenity"="university"]', '["amenity"="kindergarten"]'],
  bank: ['["amenity"="bank"]', '["amenity"="atm"]'],
  construction: ['["office"="construction_company"]', '["craft"="builder"]', '["shop"="building_materials"]'],
  real_estate: ['["office"="estate_agent"]'],
  car_service: ['["shop"="car_repair"]', '["amenity"="car_wash"]'],
  fuel: ['["amenity"="fuel"]'],
  all_businesses: ['["name"]["amenity"]', '["name"]["shop"]', '["name"]["office"]', '["name"]["tourism"]', '["name"]["craft"]']
};

let mainWindow;
let activeController = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: '#08111f',
    title: 'Map Leads',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

function sendProgress(stage, percent, message, extra = {}) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send('search-progress', { stage, percent, message, ...extra });
}

function historyPath() {
  return path.join(app.getPath('userData'), 'search-history.json');
}

async function readHistory() {
  try {
    const content = await fs.readFile(historyPath(), 'utf8');
    return JSON.parse(content);
  } catch {
    return [];
  }
}

async function saveHistory(entry) {
  const history = await readHistory();
  history.unshift(entry);
  await fs.writeFile(historyPath(), JSON.stringify(history.slice(0, 40), null, 2), 'utf8');
}

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (signal) {
      signal.addEventListener('abort', () => {
        clearTimeout(timer);
        reject(new DOMException('Search cancelled', 'AbortError'));
      }, { once: true });
    }
  });
}

async function fetchJson(url, options = {}, retries = 2) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'User-Agent': USER_AGENT,
          'Accept-Language': 'az,en;q=0.8',
          ...(options.headers || {})
        }
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      lastError = error;
      if (error.name === 'AbortError' || attempt === retries) throw error;
      await sleep(900 * (attempt + 1), options.signal);
    }
  }
  throw lastError;
}

async function geocodeArea(area, signal) {
  const params = new URLSearchParams({
    q: area,
    format: 'jsonv2',
    limit: '5',
    addressdetails: '1',
    bounded: '0'
  });
  const results = await fetchJson(`${NOMINATIM_URL}?${params}`, { signal });
  if (!results.length) throw new Error('Ərazi tapılmadı. Şəhər, rayon və ya qəsəbə adını daha dəqiq yaz.');
  const result = results[0];
  const bbox = result.boundingbox.map(Number);
  return {
    displayName: result.display_name,
    bbox: { south: bbox[0], north: bbox[1], west: bbox[2], east: bbox[3] }
  };
}

function buildOverpassQuery(bbox, categories, limit) {
  const selected = categories.includes('all_businesses') ? ['all_businesses'] : categories;
  const filters = [...new Set(selected.flatMap((key) => CATEGORY_FILTERS[key] || []))];
  if (!filters.length) throw new Error('Ən azı bir kateqoriya seç.');
  const box = `${bbox.south},${bbox.west},${bbox.north},${bbox.east}`;
  const statements = filters.flatMap((filter) => [
    `node${filter}(${box});`,
    `way${filter}(${box});`,
    `relation${filter}(${box});`
  ]).join('\n');
  return `[out:json][timeout:90];\n(\n${statements}\n);\nout center ${Math.max(limit * 3, 300)};`;
}

async function queryOverpass(query, signal) {
  let lastError;
  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        signal,
        headers: {
          'User-Agent': USER_AGENT,
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        body: new URLSearchParams({ data: query })
      });
      if (!response.ok) throw new Error(`Overpass HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      lastError = error;
      if (error.name === 'AbortError') throw error;
    }
  }
  throw new Error(`Xəritə serverlərinə qoşulmaq olmadı: ${lastError?.message || 'naməlum xəta'}`);
}

function firstValue(tags, keys) {
  for (const key of keys) {
    const value = tags[key];
    if (value && String(value).trim()) return String(value).trim();
  }
  return '';
}

function normalizePhone(value) {
  return String(value || '')
    .split(/[;,/]/)
    .map((item) => item.trim())
    .filter(Boolean)
    .join(', ');
}

function normalizeWebsite(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  return `https://${raw}`;
}

function buildAddress(tags) {
  const full = firstValue(tags, ['addr:full', 'contact:address']);
  if (full) return full;
  return [
    tags['addr:street'],
    tags['addr:housenumber'],
    tags['addr:suburb'],
    tags['addr:city'],
    tags['addr:district'],
    tags['addr:postcode']
  ].filter(Boolean).join(', ');
}

function detectCategory(tags) {
  const entries = ['amenity', 'shop', 'office', 'tourism', 'craft', 'healthcare'];
  for (const key of entries) {
    if (tags[key]) return `${key}:${tags[key]}`;
  }
  return 'business';
}

function normalizeElement(element) {
  const tags = element.tags || {};
  const lat = element.lat ?? element.center?.lat ?? '';
  const lon = element.lon ?? element.center?.lon ?? '';
  return {
    id: `${element.type}/${element.id}`,
    name: firstValue(tags, ['name', 'brand', 'operator']) || 'Adsız obyekt',
    category: detectCategory(tags),
    phone: normalizePhone(firstValue(tags, ['contact:phone', 'phone', 'mobile', 'contact:mobile'])),
    email: firstValue(tags, ['contact:email', 'email']),
    website: normalizeWebsite(firstValue(tags, ['contact:website', 'website', 'url'])),
    address: buildAddress(tags),
    openingHours: firstValue(tags, ['opening_hours']),
    latitude: lat,
    longitude: lon,
    osmUrl: `https://www.openstreetmap.org/${element.type}/${element.id}`,
    source: 'OpenStreetMap'
  };
}

function dedupeBusinesses(items) {
  const seen = new Set();
  const output = [];
  for (const item of items) {
    const key = [item.name.toLowerCase(), item.phone.replace(/\D/g, ''), item.address.toLowerCase()].join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(item);
  }
  return output;
}

function decodeHtmlEntities(value) {
  return value
    .replace(/&#64;|&#x40;/gi, '@')
    .replace(/&#46;|&#x2e;/gi, '.')
    .replace(/&amp;/gi, '&');
}

function extractEmails(html) {
  const cleaned = decodeHtmlEntities(String(html || ''));
  const matches = cleaned.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  const ignored = /example\.|sentry\.|wixpress\.|cloudflare\.|domain\.com|email\.com/i;
  return [...new Set(matches.map((email) => email.toLowerCase()).filter((email) => !ignored.test(email)))];
}

function isPrivateIp(address) {
  if (net.isIPv4(address)) {
    const parts = address.split('.').map(Number);
    return parts[0] === 10
      || parts[0] === 127
      || parts[0] === 0
      || (parts[0] === 169 && parts[1] === 254)
      || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)
      || (parts[0] === 192 && parts[1] === 168)
      || (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127)
      || parts[0] >= 224;
  }
  if (net.isIPv6(address)) {
    const normalized = address.toLowerCase();
    return normalized === '::1'
      || normalized === '::'
      || normalized.startsWith('fc')
      || normalized.startsWith('fd')
      || normalized.startsWith('fe8')
      || normalized.startsWith('fe9')
      || normalized.startsWith('fea')
      || normalized.startsWith('feb');
  }
  return true;
}

async function assertPublicUrl(url) {
  const parsed = new URL(url);
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Unsupported protocol');
  const hostname = parsed.hostname.toLowerCase();
  if (hostname === 'localhost' || hostname.endsWith('.local')) throw new Error('Local host blocked');
  if (net.isIP(hostname) && isPrivateIp(hostname)) throw new Error('Private address blocked');
  const addresses = await dns.lookup(hostname, { all: true });
  if (!addresses.length || addresses.some((entry) => isPrivateIp(entry.address))) throw new Error('Private address blocked');
  return parsed;
}

async function fetchHtml(url, signal) {
  let currentUrl = url;
  for (let redirectCount = 0; redirectCount < 4; redirectCount += 1) {
    await assertPublicUrl(currentUrl);
    const response = await fetch(currentUrl, {
      signal,
      redirect: 'manual',
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/xhtml+xml'
      }
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      if (!location) throw new Error('Invalid redirect');
      currentUrl = new URL(location, currentUrl).href;
      continue;
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const type = response.headers.get('content-type') || '';
    if (!type.includes('text/html')) return '';
    const length = Number(response.headers.get('content-length') || 0);
    if (length > 2_000_000) return '';
    const text = await response.text();
    return text.slice(0, 2_000_000);
  }
  throw new Error('Too many redirects');
}

async function discoverEmail(website, signal) {
  if (!website) return '';
  let base;
  try {
    base = new URL(website);
  } catch {
    return '';
  }
  const urls = [
    base.href,
    new URL('/contact', base).href,
    new URL('/contact-us', base).href,
    new URL('/elaqe', base).href,
    new URL('/about', base).href
  ];
  for (const url of [...new Set(urls)]) {
    try {
      const html = await fetchHtml(url, signal);
      const emails = extractEmails(html);
      if (emails.length) return emails.slice(0, 3).join(', ');
    } catch (error) {
      if (error.name === 'AbortError') throw error;
    }
  }
  return '';
}

async function enrichEmails(items, signal) {
  const candidates = items.filter((item) => !item.email && item.website).slice(0, 80);
  let completed = 0;
  const workerCount = Math.min(3, candidates.length);
  const queue = [...candidates];

  async function worker() {
    while (queue.length) {
      const item = queue.shift();
      if (!item) return;
      item.email = await discoverEmail(item.website, signal);
      if (item.email) item.source = 'OpenStreetMap + public website';
      completed += 1;
      sendProgress('email', 60 + Math.round((completed / Math.max(candidates.length, 1)) * 34), `Saytlarda e-poçt axtarılır: ${completed}/${candidates.length}`, { completed, total: candidates.length });
      await sleep(350, signal);
    }
  }

  await Promise.all(Array.from({ length: workerCount }, () => worker()));
}

ipcMain.handle('search-businesses', async (_event, payload) => {
  if (activeController) activeController.abort();
  activeController = new AbortController();
  const signal = activeController.signal;
  const startedAt = Date.now();

  try {
    const area = String(payload.area || '').trim();
    const categories = Array.isArray(payload.categories) ? payload.categories : [];
    const limit = Math.min(Math.max(Number(payload.limit) || 500, 20), 3000);
    if (area.length < 2) throw new Error('Ərazi adını yaz.');

    sendProgress('geocode', 5, 'Ərazi tapılır...');
    const location = await geocodeArea(area, signal);

    sendProgress('overpass', 15, `Xəritə məlumatı sorğulanır: ${location.displayName}`);
    const query = buildOverpassQuery(location.bbox, categories, limit);
    const data = await queryOverpass(query, signal);

    sendProgress('normalize', 48, `${data.elements?.length || 0} xəritə obyekti emal edilir...`);
    let results = dedupeBusinesses((data.elements || []).map(normalizeElement))
      .filter((item) => item.name !== 'Adsız obyekt' || item.phone || item.email || item.website)
      .slice(0, limit);

    if (payload.enrichEmails) {
      await enrichEmails(results, signal);
    }

    if (payload.onlyWithContact) {
      results = results.filter((item) => item.phone || item.email || item.website);
    }

    sendProgress('done', 100, `${results.length} nəticə hazırdır.`, { total: results.length });
    const summary = {
      id: `${Date.now()}`,
      area,
      resolvedArea: location.displayName,
      categories,
      resultCount: results.length,
      withPhone: results.filter((item) => item.phone).length,
      withEmail: results.filter((item) => item.email).length,
      createdAt: new Date().toISOString(),
      durationMs: Date.now() - startedAt
    };
    await saveHistory(summary);
    return { ok: true, location, results, summary };
  } catch (error) {
    if (error.name === 'AbortError') return { ok: false, cancelled: true, error: 'Axtarış dayandırıldı.' };
    return { ok: false, error: error.message || 'Axtarış zamanı xəta baş verdi.' };
  } finally {
    activeController = null;
  }
});

ipcMain.handle('cancel-search', async () => {
  if (activeController) activeController.abort();
  return { ok: true };
});

ipcMain.handle('get-history', readHistory);

ipcMain.handle('clear-history', async () => {
  await fs.writeFile(historyPath(), '[]', 'utf8');
  return { ok: true };
});

ipcMain.handle('open-external', async (_event, url) => {
  if (/^https?:\/\//i.test(String(url || ''))) await shell.openExternal(url);
  return { ok: true };
});

function exportRows(results) {
  return results.map((item, index) => ({
    No: index + 1,
    Ad: item.name,
    Kateqoriya: item.category,
    Telefon: item.phone,
    Email: item.email,
    Sayt: item.website,
    Ünvan: item.address,
    'İş saatları': item.openingHours,
    Enlik: item.latitude,
    Uzunluq: item.longitude,
    'OSM linki': item.osmUrl,
    Mənbə: item.source
  }));
}

function csvEscape(value) {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

ipcMain.handle('export-results', async (_event, payload) => {
  const results = Array.isArray(payload.results) ? payload.results : [];
  if (!results.length) return { ok: false, error: 'İxrac ediləcək nəticə yoxdur.' };
  const format = payload.format === 'json' ? 'json' : payload.format === 'xlsx' ? 'xlsx' : 'csv';
  const extensions = { csv: ['csv'], json: ['json'], xlsx: ['xlsx'] };
  const response = await dialog.showSaveDialog(mainWindow, {
    title: 'Nəticələri saxla',
    defaultPath: `map-leads-${new Date().toISOString().slice(0, 10)}.${format}`,
    filters: [{ name: format.toUpperCase(), extensions: extensions[format] }]
  });
  if (response.canceled || !response.filePath) return { ok: false, cancelled: true };

  const rows = exportRows(results);
  if (format === 'json') {
    await fs.writeFile(response.filePath, JSON.stringify(rows, null, 2), 'utf8');
  } else if (format === 'xlsx') {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Bizneslər', { views: [{ state: 'frozen', ySplit: 1 }] });
    const headers = Object.keys(rows[0]);
    worksheet.columns = headers.map((header, index) => ({
      header,
      key: header,
      width: [6, 28, 22, 20, 28, 32, 42, 20, 14, 14, 42, 24][index] || 18
    }));
    worksheet.addRows(rows);
    worksheet.getRow(1).font = { bold: true };
    worksheet.autoFilter = { from: 'A1', to: `${String.fromCharCode(64 + headers.length)}1` };
    await workbook.xlsx.writeFile(response.filePath);
  } else {
    const headers = Object.keys(rows[0]);
    const csv = '\uFEFF' + [headers.map(csvEscape).join(','), ...rows.map((row) => headers.map((header) => csvEscape(row[header])).join(','))].join('\r\n');
    await fs.writeFile(response.filePath, csv, 'utf8');
  }
  return { ok: true, filePath: response.filePath };
});
