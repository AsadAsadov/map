const categories = [
  ['restaurant', 'Restoran / kafe'],
  ['hotel', 'Otel'],
  ['pharmacy', 'Aptek'],
  ['clinic', 'Klinika / xəstəxana'],
  ['market', 'Market / AVM'],
  ['beauty', 'Salon / bərbər'],
  ['education', 'Məktəb / təhsil'],
  ['bank', 'Bank / ATM'],
  ['construction', 'Tikinti'],
  ['real_estate', 'Əmlak agentliyi'],
  ['car_service', 'Avtoservis'],
  ['fuel', 'Yanacaqdoldurma'],
  ['all_businesses', 'Bütün bizneslər']
];

const state = {
  results: [],
  filtered: [],
  searching: false
};

const el = (id) => document.getElementById(id);
const searchForm = el('searchForm');
const categoryGrid = el('categoryGrid');
const resultsBody = el('resultsBody');
const tableSearch = el('tableSearch');
const contactTypeFilter = el('contactTypeFilter');

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function safeUrl(url) {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) ? parsed.href : '';
  } catch {
    return '';
  }
}

function showToast(message, isError = false) {
  const toast = el('toast');
  toast.textContent = message;
  toast.className = `toast visible${isError ? ' error' : ''}`;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.className = 'toast'; }, 3200);
}

function renderCategories() {
  categoryGrid.innerHTML = categories.map(([value, label], index) => `
    <label class="category-chip">
      <input type="checkbox" value="${value}" ${index === 0 ? 'checked' : ''}>
      <span>${label}</span>
    </label>
  `).join('');

  categoryGrid.addEventListener('change', (event) => {
    if (event.target.value === 'all_businesses' && event.target.checked) {
      categoryGrid.querySelectorAll('input').forEach((input) => {
        if (input !== event.target) input.checked = false;
      });
    } else if (event.target.checked) {
      const all = categoryGrid.querySelector('input[value="all_businesses"]');
      if (all) all.checked = false;
    }
  });
}

function selectedCategories() {
  return [...categoryGrid.querySelectorAll('input:checked')].map((input) => input.value);
}

function setSearching(searching) {
  state.searching = searching;
  el('searchButton').disabled = searching;
  el('searchButton').textContent = searching ? 'Axtarılır...' : 'Axtarışa başla';
  el('cancelButton').classList.toggle('hidden', !searching);
  if (searching) el('progressPanel').classList.remove('hidden');
}

function updateStats(results) {
  el('totalStat').textContent = results.length;
  el('phoneStat').textContent = results.filter((item) => item.phone).length;
  el('emailStat').textContent = results.filter((item) => item.email).length;
  el('websiteStat').textContent = results.filter((item) => item.website).length;
}

function valueOrDash(value) {
  return value ? escapeHtml(value) : '<span class="muted-value">—</span>';
}

function renderResults() {
  const query = tableSearch.value.trim().toLowerCase();
  const filter = contactTypeFilter.value;
  state.filtered = state.results.filter((item) => {
    const haystack = [item.name, item.category, item.phone, item.email, item.address, item.website].join(' ').toLowerCase();
    if (query && !haystack.includes(query)) return false;
    if (filter === 'phone' && !item.phone) return false;
    if (filter === 'email' && !item.email) return false;
    if (filter === 'website' && !item.website) return false;
    if (filter === 'missing' && item.phone && item.email && item.website) return false;
    return true;
  });

  el('resultInfo').textContent = `${state.filtered.length} / ${state.results.length} nəticə göstərilir.`;
  if (!state.filtered.length) {
    resultsBody.innerHTML = '<tr class="empty-row"><td colspan="8">Uyğun nəticə tapılmadı.</td></tr>';
    return;
  }

  resultsBody.innerHTML = state.filtered.map((item, index) => {
    const website = safeUrl(item.website);
    const osm = safeUrl(item.osmUrl);
    return `
      <tr>
        <td>${index + 1}</td>
        <td><strong>${escapeHtml(item.name)}</strong>${osm ? `<small><a href="#" data-url="${escapeHtml(osm)}">Xəritədə aç</a></small>` : ''}</td>
        <td>${valueOrDash(item.category)}</td>
        <td>${valueOrDash(item.phone)}</td>
        <td>${valueOrDash(item.email)}</td>
        <td>${valueOrDash(item.address)}</td>
        <td>${website ? `<a href="#" data-url="${escapeHtml(website)}">${escapeHtml(new URL(website).hostname)}</a>` : '<span class="muted-value">—</span>'}</td>
        <td><span class="source-badge">${escapeHtml(item.source)}</span></td>
      </tr>
    `;
  }).join('');
}

function enableResultTools(enabled) {
  document.querySelectorAll('.export-button').forEach((button) => { button.disabled = !enabled; });
  tableSearch.disabled = !enabled;
  contactTypeFilter.disabled = !enabled;
}

async function loadHistory() {
  const history = await window.mapLeads.getHistory();
  const list = el('historyList');
  if (!history.length) {
    list.innerHTML = '<div class="history-item"><strong>Axtarış tarixçəsi boşdur</strong></div>';
    return;
  }
  list.innerHTML = history.slice(0, 12).map((item) => `
    <div class="history-item">
      <strong title="${escapeHtml(item.resolvedArea || item.area)}">${escapeHtml(item.area)}</strong>
      <span><em>${item.resultCount} nəticə</em><em>${new Date(item.createdAt).toLocaleDateString('az-AZ')}</em></span>
    </div>
  `).join('');
}

searchForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const selected = selectedCategories();
  if (!selected.length) {
    showToast('Ən azı bir kateqoriya seç.', true);
    return;
  }

  setSearching(true);
  state.results = [];
  state.filtered = [];
  updateStats([]);
  enableResultTools(false);
  resultsBody.innerHTML = '<tr class="empty-row"><td colspan="8">Xəritə məlumatı toplanır...</td></tr>';

  const response = await window.mapLeads.search({
    area: el('areaInput').value,
    categories: selected,
    limit: Number(el('limitInput').value),
    enrichEmails: el('emailEnrichment').checked,
    onlyWithContact: el('contactFilter').value === 'contact'
  });

  setSearching(false);
  if (!response.ok) {
    el('progressPanel').classList.add('hidden');
    resultsBody.innerHTML = `<tr class="empty-row"><td colspan="8">${escapeHtml(response.error || 'Axtarış alınmadı.')}</td></tr>`;
    showToast(response.error || 'Axtarış alınmadı.', !response.cancelled);
    return;
  }

  state.results = response.results;
  el('resolvedArea').textContent = response.location.displayName;
  updateStats(state.results);
  enableResultTools(state.results.length > 0);
  renderResults();
  showToast(`${state.results.length} nəticə tapıldı.`);
  await loadHistory();
});

el('cancelButton').addEventListener('click', () => window.mapLeads.cancelSearch());
tableSearch.addEventListener('input', renderResults);
contactTypeFilter.addEventListener('change', renderResults);

resultsBody.addEventListener('click', (event) => {
  const link = event.target.closest('[data-url]');
  if (!link) return;
  event.preventDefault();
  window.mapLeads.openExternal(link.dataset.url);
});

document.querySelectorAll('.export-button').forEach((button) => {
  button.addEventListener('click', async () => {
    const exportSet = state.filtered.length ? state.filtered : state.results;
    const response = await window.mapLeads.exportResults({ results: exportSet, format: button.dataset.format });
    if (response.ok) showToast('Fayl uğurla saxlanıldı.');
    else if (!response.cancelled) showToast(response.error || 'İxrac alınmadı.', true);
  });
});

el('clearHistoryButton').addEventListener('click', async () => {
  await window.mapLeads.clearHistory();
  await loadHistory();
  showToast('Axtarış tarixçəsi təmizləndi.');
});

window.mapLeads.onProgress((data) => {
  el('progressMessage').textContent = data.message;
  el('progressPercent').textContent = `${data.percent}%`;
  el('progressBar').style.width = `${Math.max(0, Math.min(100, data.percent))}%`;
  if (data.percent === 100) setTimeout(() => el('progressPanel').classList.add('hidden'), 1300);
});

renderCategories();
loadHistory();
